/*----Eran Reuven----*/
/*This is a simple js document to hide after 5 sec alerts.*/
window.setTimeout("document.getElementById('alert').style.display='none';", 5000);
window.setTimeout("document.getElementById('alert2').style.display='none';", 5000);