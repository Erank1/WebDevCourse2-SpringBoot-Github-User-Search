package main;

import main.beans.DatabaseHandlerBean;
import main.beans.JsonConverterBean;
import main.beans.LoginSessionBean;
import main.beans.URLHandlerBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;

/**
 * SpringBootApplication class
 * Description: where we declare the beans
 */
@SpringBootApplication
public class Application {


    /**
     * Function: loginSessionBeanv
     * Description: we declare a bean to be created by Spring in each user session
     * @return an instance loginSessionBean
     */
    @Bean
    @Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public LoginSessionBean loginSessionBeanv () {

        return new LoginSessionBean();
    }
    /**
     * Function: urlhandlerbean
     * Description: we declare a bean to be created by Spring as singleton
     * @return an instance URLHandlerBean
     */
    @Bean
    @Scope("singleton")
    public URLHandlerBean urlhandlerbean(){
        return new URLHandlerBean();
    }
    /**
     * Function: jsonConverterBeanv
     * Description: we declare a bean to be created by Spring as singleton
     * @return an instance JsonConverterBean
     */
    @Bean
    @Scope("singleton")
    public JsonConverterBean jsonConverterBeanv(){
        return new JsonConverterBean();
    }
    /**
     * Function: DBadHandling
     * Description: we declare a bean to be created by Spring as singleton
     * @return an instance DatabaseHandlerBean
     */
    @Bean
    @Scope("singleton")
    public DatabaseHandlerBean DBadHandling(){
        return new DatabaseHandlerBean();
    }

    /**
     * Function: main
     * description: The application main function.
     * @param args
     */
    public static void main(String[] args) {

        SpringApplication.run(Application.class, args);
    }
}
