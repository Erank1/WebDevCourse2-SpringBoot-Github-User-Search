package main.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * interface: UserRespository
 * Description: extends JpaRepository. it use to run queries in the
 *              Database.
 */
public interface UserRepository extends JpaRepository<GHuser, Long> {
    /**
     * Function: findByUserName
     * Description: finding in DB the user by username
     * @param userName to check
     * @return the user object (GHuser)
     */
    GHuser findByUserName(String userName);

    /**
     * Function: existsByUserName
     * Description: check if a user is exist or not (boolean answer)
     * @param userName to check
     * @return boolean value as explained in the Description.
     */
    boolean existsByUserName(String userName);

    /**
     * Function: findFirst10ByOrderByNumOfSearchesDesc
     * Description: will return a list of the 10 most members search
     *              from the database in Decrease order
     * @return List of GHuser object.
     */
    List<GHuser> findFirst10ByOrderByNumOfSearchesDesc();
    /**
     * Function: findAll
     * Description: will return a list of all table content
     *              from the database in Decrease order
     * @return List of GHuser object.
     */
    List<GHuser> findAll();
}
