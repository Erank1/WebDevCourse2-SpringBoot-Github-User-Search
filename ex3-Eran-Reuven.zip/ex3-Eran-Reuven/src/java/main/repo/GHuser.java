package main.repo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

/**
 * Entity Class: GHuser
 * Description: this is the object we create to insert to the database.
 *              It has generated ID, and fields we inject to the DB table by @Entity
 *
 * Members:
 * id - Generated id for the database
 * userName - the username (parameter of the github search, if valid and exist)
 * urlPath - the urlPath will hold the user api json link
 * numOfSearches - will hold the search counter. if created, it will be 1.
 */
@Entity
public class GHuser {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @NotBlank(message = "U have to pick an assign username from GitHub")
    private String userName;

    private String urlPath;
    private int numOfSearches;

    /**
     * Constructor: default c'tor
     */
    public GHuser() {}

    /**
     * Constructor: c'tor with args.
     * Description: once it made, that means the search is valid and it has been done.
     * so num of search will initial to 1.
     * @param userName userName that we will place in userName member
     * @param urlPath urlPath that we will place in urlPath member
     */
    public GHuser(String userName, String urlPath) {
        this.userName = userName;
        this.urlPath = urlPath;
        this.numOfSearches = 1;
    }

    /**
     * Function: setID
     * Description: Standart setter
     * @param id id to place in id member
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Function: getId
     * Description: Standart getter
     * @return id filed
     */

    public long getId() {
        return id;
    }

    /**
     * Function: setUserName
     * Description: Standart Setter
     * @param userName string to place in userName member.
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Function: getUserName
     * Description: standart Getter
     * @return return the userName member
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Function: setUrlPath
     * Description: Standart Setter
     * @param url to place in urlPath member
     */
    public void setUrlPath(String url) {this.urlPath = url;}

    /**
     * Function: getUrlPath
     * Description: standart getter
     * @return return the urlPath member
     */
    public String getUrlPath() { return urlPath;}

    /**
     * Function: setNumOfSearches
     * Description: Standart setter
     * @param s s to plaice in numOfSearches
     */
    public void setNumOfSearches(int s) {this.numOfSearches = s;}

    /**
     * Function: getNumOfSearches
     * Description: Standart Getter
     * @return numOfSearches member
     */
    public int getNumOfSearches() {return numOfSearches;}


    /**
     * Function: toString
     * Description: override toStrong (standart)
     * @return String format
     */
    @Override
    public String toString() {
        return String.format(
                "GHuser{userName='%s', numOfSearch='%d'}",
                userName, numOfSearches);

    }
}

