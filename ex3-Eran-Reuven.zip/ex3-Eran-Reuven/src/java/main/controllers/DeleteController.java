package main.controllers;

import main.beans.DatabaseHandlerBean;
import main.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;

/**
 * Controller: DeleteController
 * Description: this controller will handle the delete request
 *              to clean the database table content.
 * Members:
 *          DBHandler: injected by @Resource, the bean that handling the
 *                      Database requests (DatabaseHandlerBean)
 */
@Controller
public class DeleteController {

    @Resource(name="DBadHandling")
    private DatabaseHandlerBean DBHandler;

    /**
     * Mapping Function: to path /delete
     * Description: Will handle the deletion request and return
     *              the String from ClearDB method (index) and modified model
     * @param model the model
     * @return index template after model modification in ClearDB.
     */
    @PostMapping("/delete")
    public String deleteDB(Model model)
    {
        return DBHandler.ClearDB(model);
    }
    @GetMapping("/delete")
    public String getReq() {return "index";}

}
