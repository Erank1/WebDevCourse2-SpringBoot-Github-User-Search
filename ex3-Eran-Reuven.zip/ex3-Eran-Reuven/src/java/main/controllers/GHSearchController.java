package main.controllers;

import com.google.gson.JsonObject;
import main.beans.DatabaseHandlerBean;
import main.beans.JsonConverterBean;
import main.beans.URLHandlerBean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import java.io.IOException;

/**
 * Controller: GHSearchController
 * Description:
 *              This Controller handling the Github search. it will get the parameter and than
 *              Use the explained (and will explained again in "Members" section) beans to get
 *              the json content and modifying the model to return the login and the followers details
 *              after saving / updating the database.
 *
 * Members:
 * handler - injected URLHandlerBean to make a connection to the API+param paths.
 * jsonConverter - injected JsonConverterBean to convert the document (that we connected to) content
 *                  and convert it to json.
 * DBHandler - injected DatabaseHandlerBean to save or update the db according the search if the user is
 *              valid and exist.
 * rootobj - to use cross tries scopes JsonObject to get the model info we need to present.
 */
@Controller
public class GHSearchController {

    @Resource(name="urlhandlerbean")
    private URLHandlerBean handler;

    @Resource(name="jsonConverterBean")
    private JsonConverterBean jsonConverter;

    @Resource(name="DBadHandling")
    private DatabaseHandlerBean DBHandler;

    private JsonObject rootobj;

    /**
     * Mapping Function: main
     * Description: Mapping /do-search POST requests to make the explained in the
     *              Controller description.
     * @param param the login string from the search filed.
     * @param model the model
     * @return return index with modified model (when no exception throws)
     */
    @PostMapping("/do-search")
    public String main(@RequestParam("username") String param, Model model) {

        try {
            handler.URLConnector(param, model);
            rootobj = jsonConverter.getAsJson(model);

            DBHandler.Add(rootobj.get("login").getAsString());
            model.addAttribute("login", rootobj.get("login").getAsString());
            model.addAttribute("followers", rootobj.get("followers").getAsString());
            model.addAttribute("dis", "block");
        }catch (IOException error){}
        finally { return "index"; }
    }

    /**
     * Mapping Function: getSearchPage
     * Description: /do-search GET requests mapping.
     * @return index template
     */
    @GetMapping("/do-search")
    public String getSearchPage(){
        return "index";
    }
}