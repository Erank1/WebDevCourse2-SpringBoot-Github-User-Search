package main.controllers;

import main.beans.DatabaseHandlerBean;
import main.repo.GHuser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

/**
 * Controller: HistoryController
 * Description: This controller handling the history content filed.
 *              It called by AJAX so it returns JSON response and the HistoryApp
 *              getting and arranging the history list (it gets the top 10 searched logins from the DB.)
 *
 * Members:
 *          DBHandler - injected to use the database conversation bean.
 */
@Controller
public class HistoryController {

    @Resource(name="DBadHandling")
    private DatabaseHandlerBean DBHandler;

    /**
     * Mapping Function: history
     * Description: (Get/Post) /history mapping requests (in our case, AJAX call)
     * @return the json 10 items list.
     */
    @RequestMapping("/history")
    public @ResponseBody
    List<GHuser> histories()
      {
        return DBHandler.Top10Searched();
      }

}
