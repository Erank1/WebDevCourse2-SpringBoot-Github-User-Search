package main.controllers;


import main.beans.LoginSessionBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * Controller: LogoutController
 * Description: Handling logout requests
 * Members: log - injected LoginSessionBean to change the logged flag
 */

@Controller
public class LogoutController {
    @Resource(name = "loginSessionBeanv")
    private LoginSessionBean log;


    /**
     * Mapping Function
     * Description: Handling GET/POST requests of /logout.
     *              it updating the SessionBean flag and return the 'login' template.
     * @return login template
     */
    @RequestMapping("/logout")
    public String getReq() {

        log.setLog(false);
        return "login";
    }
}