package main.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * Controller: MainController
 * Description: Handling the main mapping '/' page.
 */
@Controller
public class MainController {

    /**
     * Mapping Function: to '/'
     * Description: Handling (GET/POST) requests to '/'
     * @return index template
     */
    @RequestMapping("/")
    public String main() {
        return "index";
    }

}

