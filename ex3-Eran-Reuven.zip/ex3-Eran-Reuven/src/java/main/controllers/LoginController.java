package main.controllers;


import main.beans.LoginSessionBean;
import main.beans.loginHandlerPack.LoginBean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.annotation.Resource;
import javax.validation.Valid;


/**
 * Controller: LoginController
 * Description:
 *              This controller managing the login with LoginBean Object and its Custom validator.
 *              The controller path is excluded from the LoggingInterceptor so it wont redirect in loops.
 *              Its the only controller that get the full chain when the user is logged out.
 *
 * Members:
 * log - injected LoginSessionBean to check and update the login flag
 */
@Controller
public class LoginController {
    @Resource(name = "loginSessionBeanv")
    private LoginSessionBean log;

    /**
     * Mapping Function: main
     * Description:
     *              Handling POST requests to /login. it gets a LoginBean object that
     *              injected to the template by the GET function, and use its @Valid
     *              (it use the custom Validator we have.) if @Valid has error message
     *              that means the connection parameters doesn't fit the once we kept
     *              in application.properties, So we will modify the model and return
     *              the login template. if its valid,  We updating the login flag and
     *              returning the index template. Also, if the log flag is on, it return
     *              immediately index template.
     *
     * @param user the object we got from the template (view)
     * @param result the BindingResult for @Valid check
     * @param model the model
     * @return in casses explained in description: index/login
     */
    @PostMapping(path = "/login")
    public String main(@Valid LoginBean user, BindingResult result, Model model) {
        if (log.getLogged())
            return "index";

        if(result.hasErrors()) {
                model.addAttribute("message", "Hey! Wrong login details. Try again!" );
                model.addAttribute("dis", "block");
                return "login";
            }
        log.setLog(true);
        return "index";

    }

    /**
     * Mapping Function: getReq
     * Description: Handling GET requests to /login.
     *              It will add attributes (such as LoginBean object) and inject them to
     *              the login page. Also, if the log flag is on, we will return index template
     *              immediately.
     * @param model the model
     * @return index / login templates.
     */
        @GetMapping(path = "/login")
        public String getReq (Model model){
            if (log.getLogged())
                return "index";


            model.addAttribute("loginBean", new LoginBean());
            model.addAttribute("username", "");
            model.addAttribute("password", "");
            return "login";

        }
    }

