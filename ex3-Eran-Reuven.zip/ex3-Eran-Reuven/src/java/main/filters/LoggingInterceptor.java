package main.filters;

import main.beans.LoginSessionBean;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Filter: LoggingInterceptor
 * Description: Will block any redirect but login if the session bean user flag (logged) is not on.
 *              We blocking the content as long as the user is not logged in.
 *
 * Members: log is LoginSessionBean that we keep with the parameter we sending from MyConfig
 */

public class LoggingInterceptor implements HandlerInterceptor {
    private LoginSessionBean log;

    /**
     * Constructor: c'tor to initialize and keep the SessionBean
     * @param usrLogin the session bean that passed by MyConfig
     */
    public LoggingInterceptor(LoginSessionBean usrLogin) {
        this.log = usrLogin;
    }

    /**
     * Function: preHandle
     * Description: Overloded function from HandlerInterceptor.
     *              It will called before any controller mapping and
     *              check if the user is logged in (if the flag is on)
     *              if yes, it continue the chaining by return true.
     *              if no, it break the chaining and redirect to login and
     *              return false. (to break the chain)
     * @param request request parameter
     * @param response response parameter
     * @param handler Object handler
     * @return boolean answer if we break or not the chaining.
     * @throws Exception throws when cannot redirect
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        if(log.getLogged())
            return true;
        else{
            response.sendRedirect("/login");
            return false;
        }
    }
}