package main;

import main.beans.LoginSessionBean;
import main.filters.LoggingInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

/**
 * Config: MyConfig
 * Description:  this is a class for configuring SringMVC
 *   here we register our interceptor class and other configurations
 *   WebMvcConfigurer allows configuring all of the MVC
 *
 *   Members: log injected to be sended to the filter constructor
 */

@Configuration
public class MyConfig implements WebMvcConfigurer {
    @Resource(name= "loginSessionBeanv")
    private LoginSessionBean log;

    /**
     * Function: addInterceptors
     * Description: will create the filter with path patterns /** excluding /login
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry){
        registry.addInterceptor(new LoggingInterceptor(log))
                .addPathPatterns("/**")
                .excludePathPatterns("/login", "/readme.html");
    }
}