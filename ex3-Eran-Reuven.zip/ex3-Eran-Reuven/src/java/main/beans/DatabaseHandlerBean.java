package main.beans;

import main.repo.GHuser;
import main.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import javax.annotation.Resource;
import java.util.List;

/**
 *  Bean: DatabaseHandlerBean
 *  Description:
 *      This bean is to manage the Database conversations.
 *      It use by controllers: GHSearchController, HistoryController, DeleteController
 *      and do their action. (Saving new if not exist or update, get top 10 history, delete table content.
 *
 *  Members:
 *  repository - the repository bean to communicate the db by repo
 *  handler - the URL handler member is to open and connect url (using for GHSeachController)
 */
@Component
public class DatabaseHandlerBean {
    @Autowired
    private UserRepository repository;

    @Resource(name="urlhandlerbean")
    private URLHandlerBean handler;

    /**
     * Function: Add
     * Description: This function adding new github user search to the db.
     *              Its checking if the login name already exist. if yes,
     *              we increase the searchesNum filed by 1. else, we create and save
     *              a new one.
     * @param login is the login string of the github user.
     */
    public void Add(String login){
        if(repository.existsByUserName(login)) {
            GHuser usr = repository.findByUserName(login);
            usr.setNumOfSearches(usr.getNumOfSearches() + 1);
        }
        else {
            GHuser usr = new GHuser(login, handler.returnPath());
            repository.save(usr);
        }
    }

    /**
     * Function: Top10Searched
     * Description: Will return from the DB List of GHuser that in the top 10
     *              of searches.
     * @return Explained in description.
     */
    public List<GHuser> Top10Searched()
    {
        return repository.findFirst10ByOrderByNumOfSearchesDesc();
    }

    /**
     * Function: ClearDB
     * Description: Clean all the content of the Table in the DB.
     * @param model the model to add attributes for the view
     * @return index template.
     */
    public String ClearDB(Model model)
    {
        if(repository.findAll().isEmpty())
        {
            model.addAttribute("message", "Hey! History already empty.");
            model.addAttribute("disMessage", "block");
            return "index";
        }
        repository.deleteAll();
        model.addAttribute("message", "History Top 10 Search List has been cleared from the database.");
        model.addAttribute("disMessage", "block");
        return "index";
    }
}
