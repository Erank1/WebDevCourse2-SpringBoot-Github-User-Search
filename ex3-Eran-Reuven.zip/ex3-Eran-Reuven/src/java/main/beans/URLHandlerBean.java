package main.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

/**
 *  Bean: URLHandlerBean
 *  Description:
 *      This bean is to manage URL handling for GHSearchController.
 *      Technically, this bean can work with any URL api that can add login name such as github.
 *      you can change the api link from application.properties.
 *      The action is to connect to the given login api.
 *  Members:
 *  apiPath - injected by @Value from application.properties
 *  URLConnection - will use to get the url connection outside scopes of try
 *  urlPath - the complete URL. the api url + the login string.
 */
@Component
 public class URLHandlerBean {
     @Value( "${api.path}" )
     private String apiPath;

     private URLConnection request;
     private String urlPath;


    /**
     * Function: URLConnection
     * Description:
     *              This function handling the URL connection. it trim the login name, and
     *              trying to connect to the api link. if it cant, means we have a problem
     *              with the link or the api server is invalid. in that case, we modifying
     *              the model and throw exception to the controller for further handling.
     *
     * @param param the login parameter (name we have searched)
     * @param model the model
     * @return returns the URLConnection after connecting. (if exception didnt throw)
     * @throws IOException throw further to the controller from catch.
     */
     public URLConnection URLConnector(String param, Model model) throws IOException {
         try {
             param = param.trim();
             if (!param.equals("")) {
                 this.urlPath = apiPath + param;
                 URL url = new URL(this.urlPath);
                 this.request = url.openConnection();
                 this.request.connect();
             }
         }
        catch (IOException error){
                model.addAttribute("message", "Hey! Sorry... Could not connect to github API. Try again!");
                model.addAttribute("disMessage", "block");
                throw error;
            }

        return this.request;
    }

    /**
     * Function: returnPath
     * Description: Returns the urlPath (complete path, api + login)
     * @return explained in the description.
     */
    public String returnPath(){return this.urlPath;}

    /**
     * Function: getURLcontent
     * Description: to get the url contect from the connected url.
     * @return the target content
     * @throws IOException if the user is not exist, it will throw exception to
     *                      further handling in Controller.
     */
    public InputStream getURLcontent() throws IOException {
         return (InputStream) this.request.getContent();
    }

}
