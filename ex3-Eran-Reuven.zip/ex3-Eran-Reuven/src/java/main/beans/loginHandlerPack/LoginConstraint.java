package main.beans.loginHandlerPack;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Constraint: Custom validation
 * Description: Custom Annotation to validate login filed.
 *              it has filed() method to declare the filed (Further explanation at "LoginValidator"
 */

@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = LoginValidator.class)
public @interface LoginConstraint {
    String message() default "Invalid login";
    String filed();
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
