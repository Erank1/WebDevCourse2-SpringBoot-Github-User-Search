package main.beans.loginHandlerPack;

import org.springframework.stereotype.Component;

/**
 *  Bean: LoginBean
 *  Description:
 *      This bean is to keep the login data from
 *      the 'login' view. It validate by custom validator named "LoginConstraint"
 *      that use "LoginValidator".
 *
 *  Members:
 *  username: will hold username field and validate with property userName.
 *  password: will hold password field and validate with property Password.
 */

@Component
public class LoginBean {


    @LoginConstraint(filed="username")
    private String username;
    @LoginConstraint(filed="password")
    private String password;

    /**
     * Constructor: empty c'tor
     *      Description: needed empty c'tor
     */
    public LoginBean() { }

    /**
     * Constructor: overload with arguments filed c'tor.
     * Description:
     *              This constuctor has been made for template engine.
     * @param username will hold username filed
     * @param password will hold password filed
     */
    public LoginBean(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * Function: getUsername
     * Description: Standart getter
     * @return username member
     */
    public String getUsername() {return this.username;}

    /**
     * Function: setUsername
     * Description: Standart setter username member
     * @param x is the username to set
     */
    public void setUsername(String x) {this.username = x;}
    /**
     * Function: getPassword
     * Description: Standart getter
     * @return password member
     */
    public String getPassword() {return this.password;}
    /**
     * Function: setPassword
     * Description: Standart setter password member
     * @param x is the password to set
     */
    public void setPassword(String x) {this.password = x;}
}