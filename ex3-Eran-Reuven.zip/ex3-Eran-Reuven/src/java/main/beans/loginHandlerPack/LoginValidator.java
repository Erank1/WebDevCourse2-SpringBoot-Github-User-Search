package main.beans.loginHandlerPack;

import org.springframework.beans.factory.annotation.Value;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Validator Class: Custom login validation
 * Description:
 *             This class implements from ConstraintValidator with the
 *             Custom annotation 'LoginConstraint' that contain 'filed()' method
 *             to declare if we validate the username or the password. it returns
 *             in "isValid" overload method the answer.
 *
 *  Members:
 *          userLoggin: userLoggin to log. Took from application.properties by @value
 *          userPassword: userPassword to log. Took from application.properties by @value
 *          filed: to declare what field we validating.
 */

public class LoginValidator implements ConstraintValidator<LoginConstraint, String> {

   @Value("${login.userName}")
   private String userLoggin;

   @Value("${login.Password}")
   private String userPassword;

   private String filed;

   /**
    * initialize function: implement from ConstraintValidator
    * @param constraintAnnotation the constraint context
    */
   public void initialize(LoginConstraint constraintAnnotation) { ;
      filed = constraintAnnotation.filed();

   }

   /**
    * Function: isValid
    * Description:
    *             Implements from ConstraintValidator.
    *             Here we figuring with 'filed' what are we validate
    *             and validate according it. (username / password)
    *             it return boolean answer.
    * @param value the object we willing to validate
    * @param context the ConstraintValidator context
    * @return true - valid, false - invalid.
    */

   public boolean isValid(String value,
                          ConstraintValidatorContext context) {
      if(filed.equals("username"))
         return (value != null &&value.equals(userLoggin));
      else if(filed.equals("password"))
         return (value != null &&value.equals(userPassword));
      return false;
   }

}