package main.beans;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *  Bean: JsonConverterBean
 *  Description:
 *      This bean is to manage the Json Convert for the GithubAPI (GHSearchController)
 *      it also handling the problem if the user is not exist (no content to get by 'getContent' method)
 *      and update the model and throw the error to the controller.
 *  Members:
 *  handler - the URL handler member is to open and connect url (using for GHSeachController)
 *  root - JsonElement to hold the conversion and then we can getAsJsonObject
 */
@Component
public class JsonConverterBean {

    @Resource(name="urlhandlerbean")
    private URLHandlerBean handler;

    private JsonElement root;

    /**
     * Function: getAsJson
     * Description:
     *              This function gets the content from the given url and parse it to json object.
     *              If it fails, it will modify the model and throw error to the controller to handle.
     * @param model the model
     * @return JsonObject from the API content
     * @throws IOException throws when no such user
     */
    public JsonObject getAsJson(Model model) throws IOException {
        try {
            this.root = JsonParser.parseReader(new InputStreamReader((handler.getURLcontent()))); //Convert the input stream to a json element
        }
        catch (IOException error){
            model.addAttribute("message", "Hey! This account is not even exist. Try to search a new one!");
            model.addAttribute("disMessage", "block");
            throw error;
        }
        return this.root.getAsJsonObject(); //May be an array, may be an object.
    }
}
