package main.beans;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 *  Bean: LoginSessionBean
 *  Description:
 *      This bean is to manage the session. it configure to create by session and it hold
 *      a boolean that flag if that session is logged in or with up to date session, or its not.
 *      That way with this bean we can figure and block logged in content and redirect to login
 *      if not.
 *  Members:
 *  logged - a boolean flag to say if the user by this session is logged in or not.
 */
@Component
public class LoginSessionBean implements Serializable {
    private boolean logged;

    /**
     * Constructor: c'tor for configuration
     * Description: init the flag and created as instance in MyConfig
     */
    public LoginSessionBean() {
        this.logged = false;
    }

    /**
     * Function: getLogged
     * Description: Standart getter
     * @return logged flag member
     */
    public boolean getLogged(){return logged;}

    /**
     * Function: setLog
     * Description: Standart setter
     * @param v the value to set in the flag logged
     */
    public void setLog(boolean v){this.logged = v;}
}